<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Epc_reports
 *
 * @author pavaningalkar
 */
class Sa_vin_search extends CI_Controller {
    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->library("session");
        $this->load->helper('url');
        $this->load->library('breadcrumbs'); /*for breadcrumbs*/
        $this->load->database();
        $this->load->library('S3');/* for AWS S3 bucket Transactions */

    }
    public function Vindetails() {
        
        $this->load->view('sa/vin_search');
    }
    
    public function get_manufacturing_details() {
       $vin_no =  $this->input->post('vin_no');       
       /*get details from manufacturing data*/
       if(empty($vin_no)){
           $op['data']['status'] =  FALSE;
           echo json_encode($op);
           return true;
       }
       $this->db->select('*');
       $this->db->from('gm_manufacturingdata AS md');
       !empty($vin_no) ? $this->db->where('md.product_id',$vin_no) : "";       
       $query = $this->db->get();
       $manufacturing_data =  ($query->num_rows() > 0)? $query->result_array():FALSE;
       if($manufacturing_data){
           $op['data']['status'] =  TRUE;
           $op['data']['sku_code'] = substr($manufacturing_data[0]['material_number'], 0, -2)."ZZ"; 
           $op['data']['plant'] = $manufacturing_data[0]['plant'];
           $op['data']['vehicle_off_line_date'] = date("d-m-Y", strtotime($manufacturing_data[0]['vehicle_off_line_date']) );
       }else{
           $op['data']['status'] =  FALSE;
       }
       echo json_encode($op);
       return TRUE;
    }
    public function Vindetails_ajax() {
        $vin_no =$this->input->post('vin_no');
        $plant =$this->input->post('plant');
        $sku_code =$this->input->post('sku_code');
        
        
        $dates_to_from = (!empty($this->input->post('month_year'))) ? $this->input->post('month_year') : "";
        
        
        $this->load->library('Ajax_pagination');
        $this->perPage = 20;
        $page = $this->input->post('page');
        $offset = !empty($page) ? $page : 0;
        /*make database Connection  and assign result to $data_set */

        $query0 = $this->vindetails_db( $plant,$sku_code, date('Y-m-d', strtotime($dates_to_from)),null,null);
        $data_set =  ($query0->num_rows() > 0)? $query0->result_array():FALSE;
        $totalRec = $query0->num_rows();
        
        //pagination configuration
        $config['target']      = '#documentlist';
        $config['base_url']    = base_url().'Sa_vin_search/Vindetails_ajax';
        $config['total_rows']  = $totalRec;
        $config['per_page']    =  $this->perPage;
        
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //$data['data_set_dtl'] = ($data_set) ? array_slice($data_set,$offset,$this->perPage) : FALSE;
        $query = $this->vindetails_db($plant, $sku_code, date('Y-m-d', strtotime($dates_to_from)),$offset,$this->perPage);
        $data['data_set_dtl'] =  ($query->num_rows() > 0)? $query->result_array():FALSE;
        $this->load->view('sa/pagination/vinsearch',$data);
    }
    public function download_vindetails() {
        $vin_no =$this->input->get('vin_no');
        $sku_code =$this->input->get('sku_code');
        $plant =$this->input->get('plant');
        
        
        $dates_to_from = (!empty($this->input->get('month_year'))) ? $this->input->get('month_year') : "";
        
        $filename = 'VinSearch_details_'.date('Ymd').'.csv'; 
        header("Content-Description: File Transfer"); 
        header("Content-Disposition: attachment; filename=$filename"); 
        header("Content-Type: application/csv; ");   
        $query = $this->vindetails_db($plant, $sku_code, date('Y-m-d', strtotime($dates_to_from)),NULL,null);
        
        $target_dtl =  ($query->num_rows() > 0)? $query->result_array():FALSE;
        
        $file = fopen('php://output', 'w');

            $header = array();
            $header[]="Manufacture date";
            $header[]="SKU Code";
            $header[]="SKU Code  Description";
            $header[]="Node ID";
            $header[]="Component";
            $header[]="Component Description";
            $header[]="Plant";
            $header[]="Valid From";
            $header[]="Valid To";
            $header[]="Locator code";
            $header[]="Locator Description";
            $header[]="Service Tag";
            $header[]="Current Service Tag";
            $header[]="Change Date";
            $header[]="Status";
            
            fputcsv($file, $header);
            if($target_dtl){
            foreach ($target_dtl as $key=>$line){ 
              fputcsv($file,$line); 
            }
            }
            fclose($file); 
            exit; 
        
    }
    private function vindetails_db($plant,$sku_code,$dates,$offset,$perpage ) {
        $ver = 0;
        if(!empty($sku_code)){
            $this->db->select('id As version');
            $this->db->from('gm_bomheader AS bh');
            $this->db->where('sku_code',$sku_code);
            $this->db->order_by('created_date','DESC');
            $this->db->limit(1);
            $query = $this->db->get();
            $data_set =  ($query->num_rows() > 0)? $query->result_array():FALSE;
            $ver = $data_set[0]['version'];
        } 
        
      //  $this->db->select("md.product_id,DATE_FORMAT(md.vehicle_off_line_date, '%d-%m-%Y') AS vehicle_off_line_date,md.plant ,skd.sku_description,CONCAT(SUBSTRING(material_number, 1, CHAR_LENGTH(md.material_number) - 2),'ZZ') AS sku_code ");
    $this->db->select("'".$dates."' AS manufacturing_date");
    $this->db->select("bh.sku_code");
    $this->db->select("skd.sku_description");
    $this->db->select("bi.item_id AS node_id");
    $this->db->select("bi.part_number");
    $this->db->select("bi.material_description");
    $this->db->select("bh.plant");
    $this->db->select("bi.valid_from");
    $this->db->select("bi.valid_to");
    $this->db->select("bi.serial_number");
    $this->db->select("CONCAT_WS('-',locater.main_group,locater.sub_group) AS locators_description");
    $this->db->select("IFNULL(h.old_tag, '--') AS old_tag");
    $this->db->select("IFNULL(h.new_tag, '--') AS new_tag");
    $this->db->select("IFNULL(h.change_date, '--') AS change_date"); 
    $this->db->select("case  when bi.status is null  then 'INITIAL' else bi.status END AS status");
    
    $this->db->from("gm_bomitem AS bi");
//    $this->db->join("gm_bomheader AS bh","bi.bom_id = bh.id","left");
    
    !empty($sku_code) ? $this->db->join('gm_bomheader AS bh ',' bi.bom_id = bh.id AND bh.id = '.$ver,'left') : $this->db->join('gm_bomheader AS bh ',' bi.bom_id = bh.id','left');
    
    $this->db->join('gm_skudetails AS skd','skd.sku_code = bh.sku_code','left');
    $this->db->join('gm_serviceability_mtr_history AS h','h.material_number = bi.part_number','left');
    $this->db->join('gm_locator_desc AS locater ',' bi.serial_number = locater.locator_codes','left');
        !empty($dates) ?  $this->db->where("(bi.valid_from <= '".$dates."' AND ( bi.valid_to = '9999-12-31' OR '".$dates."' <= bi.valid_to)) ") : "";
        !empty($sku_code) ?  $this->db->where('bh.sku_code',$sku_code) : "";
        !empty($plant) ?  $this->db->where('bh.plant',$plant) : "";
        (!empty($offset) || $offset == 0) ? $this->db->limit($perpage,$offset) : "";
     //  $this->db->limit(10) ;
        $query0 = $this->db->get();
        
        return $query0;
    }
}
