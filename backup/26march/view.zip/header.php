<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title></title>
    <link href="<?php echo asset_url('css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset_url('css/font-awesome.min.css'); ?>" rel="stylesheet">    
    <link href="<?php echo asset_url('css/main.css'); ?>" rel="stylesheet">
    <link rel="icon" type="image/png" sizes="32x32" href="http://epc.gladminds.co/static/epc/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="http://epc.gladminds.co/static/epc/img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="http://epc.gladminds.co/static/epc/img/favicon/favicon-16x16.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!--[if lt IE 9]>
    <![endif]-->           
</head><!--/head-->

