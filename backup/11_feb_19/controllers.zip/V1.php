<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class V1 extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model("User_model");
        $this->load->library("session");
        $this->load->database();
//        $data['home'] = strtolower(__CLASS__) . '/';

        
    }

    public function login() {
        $dtl =  array();
        $segment_message = "";
      $token = $this->uri->segment(3,$segment_message = "Auth Token Not Found");
      if($token == $segment_message){
          show_error($segment_message);
      } else {
          
                $this->db->select('au.id AS user_id,
                au.first_name,
                au.last_name,
                au.password,
                au.username,
                role.name AS role_name,
                role.id AS role_id,
                bv.name AS vertical_name,
                bv.id AS vertical_id');
		$this->db->from('oauth2_accesstoken AS t');
                $this->db->join('auth_user AS au','t.user_id=au.id');
                $this->db->join('gm_epcuserprofileroles AS up','up.userprofile_id = au.id', 'left');
                $this->db->join('gm_epcroles AS role','role.id = up.role_id', 'left');
                $this->db->join('gm_brandvertical AS bv','bv.id = role.vertical_id', 'left');
//                $this->db->join('auth_user_groups AS aug','t.user_id = aug.user_id','left');
//                $this->db->join('auth_group AS ag','ag.id = aug.group_id','left');
//                $this->db->join('auth_user AS au','au.id = t.user_id','left');
                $this->db->where('t.token',$token);
                $this->db->where('date(t.expires) >=','date(now())',FALSE);
                $query = $this->db->get();
		$auth_token_info = ($query->num_rows() > 0)? $query->result_array():FALSE;
//                echo $this->db->last_query(); 
                print_r($auth_token_info);  die;
          if($auth_token_info){
              foreach ($auth_token_info as $key => $value) {                
                        $dtl['user_id'] = $value['user_id'];
                        $dtl['username'] = $value['username'];
                        $dtl['email'] = $value['email'];
                        $dtl['first_name'] = $value['first_name'];
                        $dtl['last_name'] = $value['last_name'];
                        $dtl['group'][$key]['group_name'] = $value['group_name'];
                        $dtl['group'][$key]['group_id'] = $value['group_id'];                         
              }
            $dtl['logged_in']= TRUE;
            $this->session->set_userdata($dtl);
            redirect(base_url()."Uniquebilled");
          } else {
              show_error("Sorry,Token Expire!!");
          }
      }       
        
        
    }

}
